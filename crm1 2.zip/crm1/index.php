<!DOCTYPE html>
<html lang="en">
<head>
 <?php include("metatags.php"); ?>
</head>
<body>
<?php include("menu.php"); ?>
<img src="images/crmpicture1.jpeg" alt="">


</body>
</html>
