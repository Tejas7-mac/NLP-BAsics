<?php
/**
 * @package     local_crm1
 * @author      Tejas
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @var stdClass $plugin
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_crm1';
$plugin->version = 2020071901;
$plugin->requires = 2016052300;// Moodle version